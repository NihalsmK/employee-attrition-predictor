"""
Employee Attrition Predictor

A comprehensive machine learning system for HR analytics and employee retention.
"""

__version__ = "1.0.0"
__author__ = "Data Science Intern"