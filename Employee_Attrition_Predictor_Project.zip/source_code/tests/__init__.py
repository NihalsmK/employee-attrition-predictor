"""
Test suite for Employee Attrition Predictor
"""